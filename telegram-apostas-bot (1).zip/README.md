# Telegram Apostas Bot

Um bot do Telegram para enviar oportunidades de apostas seguras ao vivo.